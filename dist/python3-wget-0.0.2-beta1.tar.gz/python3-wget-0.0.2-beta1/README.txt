# python3-wget

Installation
============

With pip
========

    sudo pip3 install python3-wget

From source
===========

    python3 setup.py install

Usage
=====

  python -m wget [options] <URL>

  options:
    -o --output FILE|DIR   output filename or directory


API Usage
=========

  >>> import wget
  >>> url = 'http://www.futurecrew.com/skaven/song_files/mp3/razorback.mp3'
  >>> filename = wget.download(url)
  70% [###################################               ]            75M / 107M

  >> filename
  'razorback.mp3'

Alternative progress bar:

  >>> wget.download(url, bar=bar_thermometer)

TODO - I will do these by version 0.1.0
====
 * Implement a way to resume downloads.
 * Add options to be more like the *nix wget utility.
 * Implement download speed.


ChangeLog - (For this current version - now maintained by JamieJackHerer)
=========
0.0.2-beta1
 * Now uses human readable sizes r.e. it displays size in K/M/G/P (kilobytes/megabytes/gigabytes/petabytes)
 * Progress bar uses '[####  ]' format instead of '[....   ]'
 * Reformatted for Python 3.x
 * Included 'hurry.filesize' as a dependency in setup.py


Jamie Lindsey AKA JamieJackHerer <jackherer026@gmail.com>

+========================================================================+
|********* Anything below this message has nothing to do with me ********|
|********* but it is still implemented in the new versions **************|
|********* any changes made will now be noted above *********************|
+========================================================================+
ChangeLog - (For original package which seems to no longer be in development)
=========
2.2 (2014-07-19)
 * it again can download without -o option

2.1 (2014-07-10)
 * it shows command line help
 * -o option allows to select output file/directory

   * download(url, out, bar) contains out parameter

2.0 (2013-04-26)
 * it shows percentage
 * it has usage examples
 * it changes if being used as a library

   * download shows progress bar by default
   * bar_adaptive gets improved algorithm
   * download(url, bar) contains bar parameter
     * bar(current, total)
   * progress_callback is named callback_progress

1.0 (2012-11-13)
 * it runs with Python 3

0.9 (2012-11-13)
 * it renames file if it already exists
 * it can be used as a library

   * download(url) returns filename
   * bar_adaptive() draws progress bar
   * bar_thermometer() simplified bar

0.8 (2011-05-03)
 * it detects filename from HTTP headers

0.7 (2011-03-01)
 * compatibility fix for Python 2.5
 * limit width of progress bar to 100 chars

0.6 (2010-04-24)
 * it detects console width on POSIX

0.5 (2010-04-23)
 * it detects console width on Windows

0.4 (2010-04-15)
 * it shows cute progress bar

0.3 (2010-04-05)
 * it creates temp file in current dir

0.2 (2010-02-16)
 * it tries to detect filename from URL

0.1 (2010-02-04)
 * it can download file


Release Checklist
=================

| [ ] update version in wget.py
| [x] update description in setup.py
| [ ] python setup.py check -mrs
| [ ] python setup.py sdist upload
| [ ] tag hg version

--
anatoly techtonik <techtonik@gmail.com>
